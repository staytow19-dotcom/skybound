import { Flight, Hotel, TravelPackage, VisaReq, Booking } from './types';

export const MOCK_FLIGHTS: Flight[] = [
  {
    id: 'F001',
    airline: 'US-Bangla Airlines',
    flightNumber: 'BS-101',
    from: 'DAC',
    to: 'CXB',
    departureTime: '10:00 AM',
    arrivalTime: '11:00 AM',
    price: 4500,
    logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=40&h=40&fit=crop'
  },
  {
    id: 'F002',
    airline: 'Biman Bangladesh',
    flightNumber: 'BG-202',
    from: 'DAC',
    to: 'LHR',
    departureTime: '09:00 PM',
    arrivalTime: '07:00 AM',
    price: 85000,
    logo: 'https://images.unsplash.com/photo-1617720346853-a2d672879573?w=40&h=40&fit=crop'
  },
  {
    id: 'F003',
    airline: 'NovoAir',
    flightNumber: 'VQ-901',
    from: 'DAC',
    to: 'CGP',
    departureTime: '08:30 AM',
    arrivalTime: '09:15 AM',
    price: 3800,
    logo: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=40&h=40&fit=crop'
  }
];

export const MOCK_HOTELS: Hotel[] = [
  {
    id: 'H001',
    name: 'Sea Pearl Beach Resort',
    location: 'Cox\'s Bazar',
    rating: 5,
    pricePerNight: 12000,
    image: 'https://images.unsplash.com/photo-1571896349842-6e53ce41e8f2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'H002',
    name: 'Radisson Blu Water Garden',
    location: 'Dhaka',
    rating: 5,
    pricePerNight: 18000,
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'H003',
    name: 'Hotel The Cox Today',
    location: 'Cox\'s Bazar',
    rating: 4,
    pricePerNight: 6500,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80'
  }
];

export const MOCK_PACKAGES: TravelPackage[] = [
  {
    id: 'P001',
    title: 'Discover Sylhet Tea Gardens',
    type: 'TOUR',
    category: 'DOMESTIC',
    duration: '3 Days / 2 Nights',
    price: 8500,
    image: 'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?auto=format&fit=crop&w=800&q=80',
    includes: ['Bus Ticket', 'Eco Resort', 'Guide', 'BBQ'],
    description: 'Experience the serenity of Sylhet with a visit to the lush tea gardens, Ratargul Swamp Forest, and Bichnakandi. This package is designed for nature lovers seeking a peaceful retreat.',
    itineraryList: [
        { day: 1, title: 'Arrival & Tea Garden', desc: 'Arrive at Sylhet in the morning. Transfer to resort. Afternoon visit to Malnicherra Tea Garden. BBQ Dinner.' },
        { day: 2, title: 'Ratargul & Bichnakandi', desc: 'Full day boat tour at Ratargul Swamp Forest followed by a visit to the crystal clear waters of Bichnakandi.' },
        { day: 3, title: 'Jaflong & Departure', desc: 'Morning visit to Jaflong Zero Point. Buying local stones/crafts. Evening bus back to Dhaka.' }
    ],
    hotelDetails: [{ name: 'Grand Sylhet Resort', stars: 4, location: 'Sylhet Sadar' }]
  },
  {
    id: 'P002',
    title: 'Bali Honeymoon Special',
    type: 'TOUR',
    category: 'INTERNATIONAL',
    duration: '5 Days / 4 Nights',
    price: 85000,
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=800&q=80',
    includes: ['Air Ticket', 'Private Villa', 'Breakfast', 'Spa'],
    description: 'A romantic getaway to the Island of Gods. Enjoy private pool villas, sunset dinners, and cultural tours in Ubud and Seminyak.',
    itineraryList: [
        { day: 1, title: 'Arrival in Bali', desc: 'Airport pickup and transfer to private pool villa in Seminyak. Candlelight dinner.' },
        { day: 2, title: 'Ubud Cultural Tour', desc: 'Visit Monkey Forest, Rice Terraces, and Tegenungan Waterfall. Traditional Balinese Spa in the evening.' },
        { day: 3, title: 'Nusa Penida Day Trip', desc: 'Speedboat to Nusa Penida. Visit Kelingking Beach and Angel\'s Billabong.' },
        { day: 4, title: 'Free Day & Sunset Cruise', desc: 'Leisure time for shopping. Evening sunset dinner cruise at Jimbaran Bay.' },
        { day: 5, title: 'Departure', desc: 'Transfer to Denpasar Airport for flight back home.' }
    ],
    hotelDetails: [{ name: 'The Kayon Jungle Resort', stars: 5, location: 'Ubud' }]
  },
  {
    id: 'P003',
    title: 'Sajek Valley Clouds',
    type: 'TOUR',
    category: 'DOMESTIC',
    duration: '3 Days / 2 Nights',
    price: 6500,
    image: 'https://images.unsplash.com/photo-1627582458428-2b28c2800e84?auto=format&fit=crop&w=800&q=80',
    includes: ['Jeep Safari', 'Cottage Stay', 'All Meals']
  },
  {
    id: 'P004',
    title: 'Dubai City Tour',
    type: 'TOUR',
    category: 'INTERNATIONAL',
    duration: '4 Days / 3 Nights',
    price: 55000,
    image: 'https://images.unsplash.com/photo-1503364998084-256ce8be1148?auto=format&fit=crop&w=800&q=80',
    includes: ['Visa', '3 Star Hotel', 'Desert Safari', 'Dhow Cruise']
  },
  {
    id: 'P005',
    title: 'Sundarbans Adventure',
    type: 'TOUR',
    category: 'DOMESTIC',
    duration: '3 Days / 2 Nights',
    price: 12500,
    image: 'https://images.unsplash.com/photo-1619260584294-8a4e63f5ade5?auto=format&fit=crop&w=800&q=80',
    includes: ['Ship Cruise', 'Jungle Permit', 'All Meals', 'Security']
  },
  {
    id: 'P006',
    title: 'Kashmir Winter Vibes',
    type: 'TOUR',
    category: 'INTERNATIONAL',
    duration: '6 Days / 5 Nights',
    price: 45000,
    image: 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80',
    includes: ['Houseboat', 'Transport', 'Breakfast', 'Sightseeing']
  }
];

export const MOCK_UMRAH_PACKAGES: TravelPackage[] = [
  {
    id: 'U001',
    title: 'Economy Umrah Package',
    type: 'UMRAH',
    category: 'INTERNATIONAL',
    duration: '10 Days',
    price: 115000,
    image: 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=800&q=80',
    includes: ['Visa', 'Air Ticket', '3 Star Hotel', 'Transport'],
    description: 'Perform Umrah with ease and affordability. Our Economy Package includes flights, visa processing, and comfortable stays within walking distance of the Haram.',
    itineraryList: [
        { day: 1, title: 'Departure & Arrival in Jeddah', desc: 'Flight from Dhaka to Jeddah. Transfer to Makkah Hotel by AC Bus. Perform Umrah.' },
        { day: 2, title: 'Makkah - Ibadah', desc: 'Focus on individual Ibadah and Tawaf in Masjid Al-Haram.' },
        { day: 3, title: 'Ziyarah Makkah', desc: 'Visit historical sites: Jabal Al-Nour, Jabal Thawr, Mina, Arafat, and Muzdalifah.' },
        { day: 4, title: 'Makkah - Free Day', desc: 'Free time for prayers and shopping near Clock Tower.' },
        { day: 5, title: 'Transfer to Madinah', desc: 'Journey to Madinah by luxury bus. Check-in to Hotel near Masjid Al-Nabawi.' },
        { day: 6, title: 'Ziyarah Madinah', desc: 'Visit Masjid Quba, Masjid Qiblatain, and Uhud Mountain.' },
        { day: 7, title: 'Rawdah Visit', desc: 'Scheduled visit to Rawdah Mubarak (subject to permit app availability).' },
        { day: 8, title: 'Madinah - Ibadah', desc: 'Full day dedicated to prayers in the Prophet\'s Mosque.' },
        { day: 9, title: 'Madinah - Free Day', desc: 'Last day for shopping dates and souvenirs.' },
        { day: 10, title: 'Return to Dhaka', desc: 'Transfer to Madinah Airport for flight back to Dhaka.' }
    ],
    hotelDetails: [
        { name: 'Elaf Kinda (or similar)', stars: 3, location: 'Makkah (600m from Haram)' },
        { name: 'Artal International', stars: 3, location: 'Madinah (400m from Nabawi)' }
    ]
  },
  {
    id: 'U002',
    title: 'Premium Umrah Package',
    type: 'UMRAH',
    category: 'INTERNATIONAL',
    duration: '14 Days',
    price: 165000,
    image: 'https://images.unsplash.com/photo-1564121211835-e88c852648ab?auto=format&fit=crop&w=800&q=80',
    includes: ['Visa', 'Direct Flight', '5 Star Hotel (Near Haram)', 'VIP Bus'],
    description: 'Experience luxury and spiritual tranquility. Stay in 5-star hotels located just steps away from the Holy Mosques. Direct flights and private transfers included.',
    itineraryList: [
        { day: 1, title: 'Dhaka to Jeddah', desc: 'Direct flight via Saudia/Biman. VIP car transfer to Makkah Tower Hotel. Perform Umrah with guide.' },
        { day: 2, title: 'Makkah - Ibadah', desc: 'Jumu\'ah prayer at Haram (if Friday). Rest and Ibadah.' },
        { day: 3, title: 'Exclusive Ziyarah', desc: 'Private car tour of Islamic historical sites in Makkah.' },
        { day: 4, title: 'Makkah - Leisure', desc: 'Explore the Clock Tower mall and museum.' },
        { day: 5, title: 'Juranah Umrah', desc: 'Optional: Go to Juranah for second Umrah ihram.' },
        { day: 6, title: 'Haramain Train to Madinah', desc: 'Experience the high-speed train to Madinah. Check-in to 5-star hotel near Gate 25.' },
        { day: 7, title: 'Madinah Ziyarah', desc: 'Guided tour of historical mosques and date farms.' },
        { day: 8, title: 'Rawdah VIP Access', desc: 'Assistance for Rawdah permit booking.' },
        { day: 9, title: 'Madinah - Ibadah', desc: 'Time for spiritual reflection.' },
        { day: 10, title: 'Return', desc: 'Private transfer to airport. Return flight.' }
    ],
    hotelDetails: [
        { name: 'Swissôtel Makkah', stars: 5, location: 'Makkah (Clock Tower)' },
        { name: 'Anwar Al Madinah Mövenpick', stars: 5, location: 'Madinah (Haram boundary)' }
    ]
  },
  {
    id: 'U003',
    title: 'Ramadan Special Umrah',
    type: 'UMRAH',
    category: 'INTERNATIONAL',
    duration: '15 Days',
    price: 210000,
    image: 'https://images.unsplash.com/photo-1551041777-ed277b8dd948?auto=format&fit=crop&w=800&q=80',
    includes: ['Visa', 'Iftar', '5 Star Hotel', 'Ziyarah'],
    description: 'Spend the holy month of Ramadan in the blessed lands. Special arrangements for Suhoor and Iftar. Note: Prices subject to change based on Ramadan dates.',
    itineraryList: [
        { day: 1, title: 'Arrival', desc: 'Arrival and Umrah performance.' },
        { day: 2, title: 'Ramadan Ibadah', desc: 'Tarawih prayers in Makkah.' }
    ],
    hotelDetails: [
        { name: 'Pullman ZamZam', stars: 5, location: 'Makkah' },
        { name: 'Pullman ZamZam Madina', stars: 5, location: 'Madinah' }
    ]
  }
];

export const MOCK_DESTINATIONS = [
  { name: 'Cox\'s Bazar', image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80', price: 4500 },
  { name: 'Dubai', image: 'https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=800&q=80', price: 45000 },
  { name: 'Thailand', image: 'https://images.unsplash.com/photo-1506665531195-3566af2b4dfa?auto=format&fit=crop&w=800&q=80', price: 32000 },
  { name: 'Maldives', image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?auto=format&fit=crop&w=800&q=80', price: 65000 },
];

export const MOCK_TEAM = [
  { name: 'Rafiqul Islam', role: 'CEO & Founder', image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=400&q=80' },
  { name: 'Sarah Khan', role: 'Head of Operations', image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80' },
  { name: 'Tanvir Ahmed', role: 'Senior Travel Consultant', image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80' },
  { name: 'Nadia Rahman', role: 'Visa Specialist', image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80' },
];

export const VISA_INFO: VisaReq[] = [
  {
    country: 'Thailand',
    type: 'Tourist',
    price: 5500,
    requirements: ['Passport', 'Photo', 'Bank Statement', 'Hotel Booking']
  },
  {
    country: 'Malaysia',
    type: 'e-Visa',
    price: 6500,
    requirements: ['Passport', 'Photo', 'Return Ticket']
  },
  {
    country: 'Dubai (UAE)',
    type: 'Tourist (30 Days)',
    price: 14000,
    requirements: ['Passport', 'Photo']
  }
];

export const MOCK_BOOKINGS: Booking[] = [
  { id: 'B101', userId: 'G001', userName: 'Travel Link Bd', type: 'FLIGHT', details: 'DAC-CXB (BS-101)', amount: 4500, status: 'CONFIRMED', date: '2023-10-25' },
  { id: 'B102', userId: 'C001', userName: 'Rahim Ahmed', type: 'HOTEL', details: 'Sea Pearl (2 Nights)', amount: 24000, status: 'PENDING', date: '2023-10-26' },
  { id: 'B103', userId: 'G001', userName: 'Travel Link Bd', type: 'PACKAGE', details: 'Umrah Package', amount: 145000, status: 'CONFIRMED', date: '2023-10-24' },
  { id: 'B104', userId: 'U004', userName: 'Sarah Smith', type: 'FLIGHT', details: 'DAC-LHR (BG-202)', amount: 85000, status: 'CANCELLED', date: '2023-10-20' },
  { id: 'B105', userId: 'G001', userName: 'Travel Link Bd', type: 'HOTEL', details: 'Radisson Blu (1 Night)', amount: 18000, status: 'PENDING', date: '2023-10-27' },
];