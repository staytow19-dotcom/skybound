export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  AGENT = 'AGENT', // B2B
  ADMIN = 'ADMIN'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  balance?: number; // For Agents
  markup?: number; // For Agents (percentage)
}

export interface Flight {
  id: string;
  airline: string;
  flightNumber: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  price: number;
  logo: string;
}

export interface Hotel {
  id: string;
  name: string;
  location: string;
  rating: number;
  pricePerNight: number;
  image: string;
}

export interface TravelPackage {
  id: string;
  title: string;
  type: 'TOUR' | 'UMRAH';
  category?: 'DOMESTIC' | 'INTERNATIONAL';
  duration: string;
  price: number;
  image: string;
  includes: string[];
  // New detailed fields
  description?: string;
  itineraryList?: { day: number; title: string; desc: string }[];
  hotelDetails?: { name: string; stars: number; location: string }[];
}

export interface Booking {
  id: string;
  userId: string;
  userName: string;
  type: 'FLIGHT' | 'HOTEL' | 'PACKAGE';
  details: string;
  amount: number;
  status: 'CONFIRMED' | 'PENDING' | 'CANCELLED';
  date: string;
}

export interface VisaReq {
  country: string;
  type: string;
  price: number;
  requirements: string[];
}