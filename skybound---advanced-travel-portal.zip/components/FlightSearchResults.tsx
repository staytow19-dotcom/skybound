import React, { useState, useMemo } from 'react';
import { Flight } from '../types';
import { 
  Search, SlidersHorizontal, ArrowRight, Loader2, X, Check, Filter, Calendar
} from 'lucide-react';

// --- Helper Icons ---
const PlaneIcon = ({ className, size }: { className?: string, size?: number }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size || 24} 
      height={size || 24} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M2 12h20" />
      <path d="M13 2l9 10-9 10" />
    </svg>
);

// --- Sub-component: Flight Card ---
const FlightCard: React.FC<{ flight: Flight, onBook: () => void }> = ({ flight, onBook }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 md:p-6 flex flex-col md:flex-row items-center justify-between hover:shadow-md transition-all duration-300 group hover:border-blue-100 relative overflow-hidden">
    
    {/* Airline Info */}
    <div className="flex items-center gap-4 w-full md:w-1/3 border-b md:border-b-0 border-gray-100 pb-4 md:pb-0 mb-4 md:mb-0">
      <div className="relative">
        <img src={flight.logo} alt={flight.airline} className="w-12 h-12 rounded-full object-cover border border-gray-100 bg-white p-1" />
        <div className="absolute -bottom-1 -right-1 bg-blue-50 text-blue-600 rounded-full p-0.5 border border-white">
            <Check size={10} strokeWidth={4} />
        </div>
      </div>
      <div>
        <h4 className="font-bold text-gray-900 group-hover:text-blue-600 transition">{flight.airline}</h4>
        <p className="text-xs text-gray-500 flex items-center gap-1 font-medium bg-gray-50 px-2 py-0.5 rounded-full w-fit mt-1">
            {flight.flightNumber}
        </p>
      </div>
    </div>

    {/* Flight Route & Timing */}
    <div className="flex items-center justify-center gap-3 md:gap-8 w-full md:w-1/3 my-2 md:my-0 relative">
      <div className="text-center min-w-[60px]">
        <p className="text-xl font-bold text-gray-800">{flight.departureTime}</p>
        <p className="text-sm text-gray-500 font-mono bg-gray-100 px-2 rounded inline-block mt-1">{flight.from}</p>
      </div>
      
      <div className="flex flex-col items-center flex-1 px-2">
        <p className="text-[10px] text-gray-400 mb-1 uppercase tracking-wide">1h 15m</p>
        <div className="w-full h-px bg-gray-300 relative flex items-center justify-center">
          <PlaneIcon className="text-blue-500 bg-white px-2 absolute z-10" size={24} />
          <div className="absolute w-1.5 h-1.5 bg-blue-400 rounded-full left-0"></div>
          <div className="absolute w-1.5 h-1.5 bg-blue-400 rounded-full right-0"></div>
        </div>
        <p className="text-[10px] text-green-600 mt-1 font-medium">Non-stop</p>
      </div>

      <div className="text-center min-w-[60px]">
        <p className="text-xl font-bold text-gray-800">{flight.arrivalTime}</p>
        <p className="text-sm text-gray-500 font-mono bg-gray-100 px-2 rounded inline-block mt-1">{flight.to}</p>
      </div>
    </div>

    {/* Price & Action */}
    <div className="w-full md:w-1/3 flex flex-row md:flex-col justify-between md:justify-center items-center md:items-end gap-2 pl-0 md:pl-8 border-t md:border-t-0 md:border-l border-gray-100 pt-4 md:pt-0 mt-4 md:mt-0">
      <div className="text-left md:text-right">
          <p className="text-xs text-gray-400 line-through">৳{(flight.price + 500).toLocaleString()}</p>
          <p className="text-2xl font-bold text-blue-600">৳{flight.price.toLocaleString()}</p>
          <p className="text-[10px] text-gray-400 hidden md:block">Includes taxes & fees</p>
      </div>
      <button 
        onClick={onBook} 
        className="bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 active:bg-blue-800 transition shadow-sm hover:shadow-md font-medium text-sm whitespace-nowrap"
      >
        Book Now
      </button>
    </div>
  </div>
);

// --- Main Component ---

interface FlightSearchResultsProps {
    flights: Flight[];
    isSearching: boolean;
    searchCriteria: { from: string; to: string; date: string };
    onModifySearch: () => void;
    onBook: (flight: Flight) => void;
}

const FlightSearchResults: React.FC<FlightSearchResultsProps> = ({ 
    flights, isSearching, searchCriteria, onModifySearch, onBook 
}) => {
    const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc'>('price_asc');
    const [filterAirlines, setFilterAirlines] = useState<string[]>([]);
    const [showMobileFilters, setShowMobileFilters] = useState(false);

    // Derive available airlines from data
    const availableAirlines = useMemo(() => {
        const airlines = new Set(flights.map(f => f.airline));
        return Array.from(airlines).sort();
    }, [flights]);

    // Filtering & Sorting Logic
    const filteredFlights = useMemo(() => {
        let result = [...flights];

        // Filter
        if (filterAirlines.length > 0) {
            result = result.filter(f => filterAirlines.includes(f.airline));
        }

        // Sort
        result.sort((a, b) => {
            if (sortBy === 'price_asc') return a.price - b.price;
            return b.price - a.price;
        });

        return result;
    }, [flights, filterAirlines, sortBy]);

    const toggleAirlineFilter = (airline: string) => {
        setFilterAirlines(prev => 
            prev.includes(airline) 
                ? prev.filter(a => a !== airline) 
                : [...prev, airline]
        );
    };

    // Filter Sidebar Content (Reused for Desktop & Mobile)
    const FilterContent = () => (
        <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200 h-full">
            <div className="flex items-center justify-between mb-6 border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2 font-bold text-gray-900">
                    <SlidersHorizontal size={18} className="text-blue-600" /> Filters
                </div>
                {filterAirlines.length > 0 && (
                    <button 
                        onClick={() => setFilterAirlines([])}
                        className="text-xs text-red-500 hover:underline font-medium"
                    >
                        Reset
                    </button>
                )}
            </div>

            {/* Airlines Filter */}
            <div className="mb-8">
                <h4 className="text-sm font-semibold mb-3 text-gray-800 uppercase tracking-wider text-[11px]">Airlines</h4>
                <div className="space-y-3">
                    {availableAirlines.map(airline => (
                        <label key={airline} className="flex items-center gap-3 cursor-pointer group hover:bg-gray-50 p-1 rounded transition">
                            <div className={`w-5 h-5 rounded border flex items-center justify-center transition ${filterAirlines.includes(airline) ? 'bg-blue-600 border-blue-600' : 'border-gray-300 bg-white'}`}>
                                {filterAirlines.includes(airline) && <Check size={12} className="text-white" />}
                            </div>
                            <input 
                                type="checkbox" 
                                checked={filterAirlines.includes(airline)}
                                onChange={() => toggleAirlineFilter(airline)}
                                className="hidden"
                            />
                            <span className="text-sm text-gray-600 group-hover:text-gray-900 font-medium">{airline}</span>
                        </label>
                    ))}
                    {availableAirlines.length === 0 && <p className="text-xs text-gray-400 italic">No airlines available</p>}
                </div>
            </div>

            {/* Stops Filter (Mock) */}
             <div className="mb-8">
                <h4 className="text-sm font-semibold mb-3 text-gray-800 uppercase tracking-wider text-[11px]">Stops</h4>
                <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer group">
                        <input type="checkbox" defaultChecked className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 border-gray-300" />
                        <span className="text-sm text-gray-600">Non-stop</span>
                        <span className="ml-auto text-xs text-gray-400">৳3,500</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer group">
                        <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 border-gray-300" />
                        <span className="text-sm text-gray-600">1 Stop</span>
                         <span className="ml-auto text-xs text-gray-400">৳8,200</span>
                    </label>
                </div>
            </div>

            {/* Price Filter (Mock) */}
             <div>
                <h4 className="text-sm font-semibold mb-3 text-gray-800 uppercase tracking-wider text-[11px]">Price Range</h4>
                <div className="px-1">
                    <input type="range" className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"/>
                </div>
                 <div className="flex justify-between text-xs text-gray-500 mt-3 font-medium">
                    <span>৳2,500</span>
                    <span>৳50,000</span>
                </div>
            </div>
        </div>
    );

    return (
      <div className="bg-slate-50 min-h-screen pb-12 animate-in fade-in duration-500">
        
        {/* Sticky Header */}
        <div className="bg-white border-b border-gray-200 sticky top-16 z-30 shadow-sm transition-all">
            <div className="max-w-7xl mx-auto px-4 py-4">
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    
                    {/* Route Info */}
                    <div className="flex items-center gap-4 md:gap-8 w-full md:w-auto justify-between md:justify-start">
                        <div className="flex items-center gap-3">
                            <div className="text-right">
                                <span className="block text-[10px] text-gray-400 uppercase font-bold tracking-wider">From</span>
                                <span className="block font-bold text-xl text-gray-900">{searchCriteria.from || '---'}</span>
                            </div>
                            <div className="bg-blue-50 p-2 rounded-full text-blue-600">
                                <ArrowRight size={20}/>
                            </div>
                             <div>
                                <span className="block text-[10px] text-gray-400 uppercase font-bold tracking-wider">To</span>
                                <span className="block font-bold text-xl text-gray-900">{searchCriteria.to || '---'}</span>
                            </div>
                        </div>

                        <div className="hidden md:block w-px h-10 bg-gray-100"></div>

                        <div className="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-lg border border-gray-100">
                            <Calendar size={16} className="text-gray-400"/>
                            <div>
                                <span className="block text-[10px] text-gray-400 uppercase font-bold tracking-wider">Departure</span>
                                <span className="block text-sm font-semibold text-gray-700">{searchCriteria.date || 'Any Date'}</span>
                            </div>
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-3 w-full md:w-auto">
                        <button 
                            onClick={() => setShowMobileFilters(true)}
                            className="md:hidden flex-1 bg-white border border-gray-200 text-gray-700 px-4 py-2.5 rounded-lg text-sm font-medium hover:bg-gray-50 flex items-center justify-center gap-2"
                        >
                            <Filter size={16}/> Filter
                        </button>
                        <button 
                            onClick={onModifySearch}
                            className="flex-1 md:flex-none bg-blue-50 text-blue-600 px-4 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-100 transition flex items-center justify-center gap-2 border border-blue-100"
                        >
                            <Search size={16}/> <span className="hidden sm:inline">Modify Search</span><span className="sm:hidden">Modify</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        {/* Main Content Grid */}
        <div className="max-w-7xl mx-auto px-4 py-6 md:py-8">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                
                {/* Desktop Filters Sidebar */}
                <div className="hidden lg:block lg:col-span-1">
                    <div className="sticky top-40">
                        <FilterContent />
                    </div>
                </div>

                {/* Mobile Filters Modal */}
                {showMobileFilters && (
                    <div className="fixed inset-0 z-50 lg:hidden">
                        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setShowMobileFilters(false)}></div>
                        <div className="absolute right-0 top-0 bottom-0 w-[80%] max-w-sm bg-white shadow-2xl animate-in slide-in-from-right duration-300 flex flex-col">
                            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                                <h3 className="font-bold text-lg text-gray-900">Filters</h3>
                                <button onClick={() => setShowMobileFilters(false)} className="p-2 hover:bg-gray-200 rounded-full transition">
                                    <X size={20} />
                                </button>
                            </div>
                            <div className="flex-1 overflow-y-auto p-4">
                                <FilterContent />
                            </div>
                            <div className="p-4 border-t border-gray-100 bg-white">
                                <button 
                                    onClick={() => setShowMobileFilters(false)}
                                    className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition"
                                >
                                    Show {filteredFlights.length} Flights
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {/* Results List */}
                <div className="lg:col-span-3">
                    
                    {/* Sort Bar */}
                    <div className="flex justify-between items-center mb-4 px-1">
                        <h2 className="text-gray-700 font-semibold">
                            {isSearching ? 'Searching...' : `${filteredFlights.length} Flights Found`}
                        </h2>
                        
                        <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-500 hidden sm:inline">Sort by:</span>
                            <select 
                                value={sortBy} 
                                onChange={(e) => setSortBy(e.target.value as any)}
                                className="bg-white border border-gray-300 text-gray-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2 outline-none cursor-pointer hover:border-blue-400 transition"
                            >
                                <option value="price_asc">Cheapest First</option>
                                <option value="price_desc">Expensive First</option>
                            </select>
                        </div>
                    </div>

                    {/* Content Logic */}
                    {isSearching ? (
                        <div className="flex flex-col items-center justify-center py-32 bg-white rounded-xl border border-gray-200 shadow-sm">
                            <Loader2 size={48} className="animate-spin text-blue-600 mb-6"/>
                            <h3 className="text-xl font-bold text-gray-900">Finding the best deals...</h3>
                            <p className="text-gray-500 mt-2">Checking real-time availability with airlines</p>
                        </div>
                    ) : filteredFlights.length > 0 ? (
                        <div className="space-y-4">
                            {filteredFlights.map((flight) => (
                                <FlightCard 
                                    key={flight.id} 
                                    flight={flight} 
                                    onBook={() => onBook(flight)} 
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-20 bg-white rounded-xl border border-gray-200 shadow-sm text-center px-4">
                            <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mb-6">
                                 <PlaneIcon size={40} className="text-gray-400 opacity-50"/>
                            </div>
                            <h3 className="text-xl font-bold text-gray-900">No Flights Found</h3>
                            <p className="text-gray-500 max-w-sm mt-2 mb-6">
                                We couldn't find flights for this specific route and date. Try adjusting your filters or search criteria.
                            </p>
                            <div className="flex gap-4">
                                <button 
                                    onClick={() => setFilterAirlines([])} 
                                    className="text-blue-600 font-medium hover:bg-blue-50 px-4 py-2 rounded-lg transition"
                                >
                                    Clear Filters
                                </button>
                                <button 
                                    onClick={onModifySearch} 
                                    className="bg-blue-600 text-white font-medium px-6 py-2 rounded-lg hover:bg-blue-700 transition"
                                >
                                    New Search
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
      </div>
    );
};

export default FlightSearchResults;