import React from 'react';
import { User, UserRole } from '../types';
import { Plane, Building, Map, CreditCard, LogOut, LayoutDashboard, Briefcase, User as UserIcon, Settings, Bot, FileText, UserCircle } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, currentPage, onNavigate }) => {
  const isPublic = !user || user.role === UserRole.CUSTOMER;

  if (isPublic) {
    return (
      <div className="min-h-screen flex flex-col bg-slate-50">
        {/* Public Navbar */}
        <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center cursor-pointer" onClick={() => onNavigate('home')}>
                <Plane className="h-8 w-8 text-blue-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">SkyBound</span>
              </div>
              <div className="hidden md:flex space-x-8 items-center">
                <button onClick={() => onNavigate('home')} className={`${currentPage === 'home' ? 'text-blue-600' : 'text-gray-600'} hover:text-blue-600 font-medium`}>Flights</button>
                <button onClick={() => onNavigate('hotels')} className={`${currentPage === 'hotels' ? 'text-blue-600' : 'text-gray-600'} hover:text-blue-600 font-medium`}>Hotels</button>
                <button onClick={() => onNavigate('packages')} className={`${currentPage === 'packages' ? 'text-blue-600' : 'text-gray-600'} hover:text-blue-600 font-medium`}>Packages</button>
                <button onClick={() => onNavigate('visa')} className={`${currentPage === 'visa' ? 'text-blue-600' : 'text-gray-600'} hover:text-blue-600 font-medium`}>Visa</button>
                <button onClick={() => onNavigate('ai-planner')} className={`${currentPage === 'ai-planner' ? 'text-purple-600' : 'text-gray-600'} hover:text-purple-600 font-medium flex items-center gap-1`}>
                    <Bot size={18}/> AI Planner
                </button>
              </div>
              <div className="flex items-center space-x-4">
                {user ? (
                   <div className="flex items-center gap-3">
                      <button 
                        onClick={() => onNavigate('profile')}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition ${currentPage === 'profile' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`}
                      >
                         <UserCircle size={20}/>
                         <span className="text-sm font-medium">{user.name}</span>
                      </button>
                      <button onClick={onLogout} className="p-2 text-gray-500 hover:text-red-600" title="Logout">
                        <LogOut size={20} />
                      </button>
                   </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <button onClick={() => onNavigate('login')} className="text-gray-600 hover:text-blue-600 font-medium px-3 py-2 transition">
                      Log In
                    </button>
                    <button onClick={() => onNavigate('register')} className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition shadow-sm">
                      Sign Up
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </nav>
        <main className="flex-grow">
          {children}
        </main>
        <footer className="bg-slate-900 text-white py-10 mt-auto">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">SkyBound</h3>
              <p className="text-slate-400 text-sm">Your trusted partner for worldwide travel, seamless bookings, and unforgettable experiences.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Services</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>Flight Booking</li>
                <li>Hotel Reservations</li>
                <li>Umrah Packages</li>
                <li>Visa Assistance</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Support</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>Contact Us</li>
                <li>Privacy Policy</li>
                <li>Terms & Conditions</li>
              </ul>
            </div>
            <div>
               <h4 className="font-semibold mb-3">Payment Methods</h4>
               <div className="flex gap-2">
                 <div className="w-10 h-6 bg-white rounded flex items-center justify-center text-xs text-black font-bold">VISA</div>
                 <div className="w-10 h-6 bg-white rounded flex items-center justify-center text-xs text-black font-bold">MC</div>
                 <div className="w-10 h-6 bg-pink-600 rounded flex items-center justify-center text-xs text-white font-bold">bKash</div>
               </div>
            </div>
          </div>
          <div className="text-center text-slate-600 text-sm mt-8 border-t border-slate-800 pt-4">
            © 2024 SkyBound Travel Tech. All rights reserved.
          </div>
        </footer>
      </div>
    );
  }

  // Admin / Agent Layout (Sidebar)
  return (
    <div className="min-h-screen bg-slate-100 flex">
      <aside className="w-64 bg-slate-900 text-white flex-shrink-0 hidden md:block">
        <div className="p-6 flex items-center gap-2">
           <Plane className="h-6 w-6 text-blue-400" />
           <span className="text-xl font-bold">SkyBound {user?.role === UserRole.AGENT ? 'B2B' : 'Admin'}</span>
        </div>
        <nav className="mt-6 px-4 space-y-2">
          <SidebarItem 
            icon={<LayoutDashboard size={20}/>} 
            label="Dashboard" 
            active={currentPage === 'dashboard'} 
            onClick={() => onNavigate('dashboard')} 
          />
          <SidebarItem 
            icon={<Briefcase size={20}/>} 
            label="Bookings" 
            active={currentPage === 'bookings'} 
            onClick={() => onNavigate('bookings')} 
          />
          {user?.role === UserRole.AGENT && (
            <SidebarItem 
              icon={<CreditCard size={20}/>} 
              label="Wallet & Markup" 
              active={currentPage === 'wallet'} 
              onClick={() => onNavigate('wallet')} 
            />
          )}
          {user?.role === UserRole.ADMIN && (
            <>
            <SidebarItem 
              icon={<Map size={20}/>} 
              label="Package CMS" 
              active={currentPage === 'cms'} 
              onClick={() => onNavigate('cms')} 
            />
            <SidebarItem 
              icon={<UserIcon size={20}/>} 
              label="Agents" 
              active={currentPage === 'agents'} 
              onClick={() => onNavigate('agents')} 
            />
            <SidebarItem 
              icon={<FileText size={20}/>} 
              label="Reports" 
              active={currentPage === 'reports'} 
              onClick={() => onNavigate('reports')} 
            />
            <SidebarItem 
              icon={<Settings size={20}/>} 
              label="Settings" 
              active={currentPage === 'settings'} 
              onClick={() => onNavigate('settings')} 
            />
            </>
          )}
        </nav>
        <div className="absolute bottom-0 w-64 p-4 border-t border-slate-800">
           {/* Profile Link in Sidebar */}
           <button 
             onClick={() => onNavigate('profile')}
             className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${currentPage === 'profile' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
           >
              <UserCircle size={20}/>
              <span className="font-medium">My Profile</span>
           </button>

          <div className="flex items-center gap-3 mb-4 pt-4 border-t border-slate-700">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center font-bold">
              {user?.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-medium truncate">{user?.name}</p>
              <p className="text-xs text-slate-400">{user?.role}</p>
            </div>
          </div>
          <button onClick={onLogout} className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 py-2 rounded text-sm transition">
            <LogOut size={16}/> Sign Out
          </button>
        </div>
      </aside>
      <main className="flex-1 p-8 overflow-y-auto">
        {children}
      </main>
    </div>
  );
};

const SidebarItem = ({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${active ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </button>
);

export default Layout;