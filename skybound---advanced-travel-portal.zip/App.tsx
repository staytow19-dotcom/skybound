import React, { useState, useEffect, useMemo, useRef } from 'react';
import { User, UserRole, Flight, Hotel, TravelPackage, Booking } from './types';
import { MOCK_HOTELS, MOCK_PACKAGES, MOCK_BOOKINGS, VISA_INFO, MOCK_FLIGHTS, MOCK_UMRAH_PACKAGES, MOCK_DESTINATIONS, MOCK_TEAM } from './constants';
import Layout from './components/Layout';
import FlightSearchResults from './components/FlightSearchResults';
import { generateTravelItinerary, askTravelAssistant } from './services/geminiService';
import { 
  Search, MapPin, Calendar, Users, Filter, CheckCircle, 
  AlertCircle, DollarSign, PieChart, TrendingUp, Send, Loader2,
  Briefcase, Settings, Building, Bot, XCircle, Eye, ArrowLeft, Lock, Mail, Plane,
  SlidersHorizontal, ChevronDown, Clock, ArrowRight, User as UserIcon,
  Plus, Minus, Trash2, Globe, Edit, CheckSquare, Save, Bell, Shield, CreditCard, Camera, Star, Award, Heart,
  Sparkles, X, MessageSquare, BookOpen, Map as MapIcon, Hotel as HotelIcon
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip, Legend, ResponsiveContainer } from 'recharts';


// --- CONFIG ---
const API_URL = 'http://localhost:5000/api';

// --- COMPONENTS ---

// 1. Home / B2C Search
const SearchTab: React.FC<{ active: boolean; label: string; icon: any; onClick: () => void }> = ({ active, label, icon: Icon, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-6 py-3 font-medium transition-all ${active ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' : 'text-gray-500 hover:text-blue-600'}`}
  >
    <Icon size={18} />
    {label}
  </button>
);

const SearchInput: React.FC<{ icon: any; placeholder: string; value?: string; onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void; type?: string; className?: string }> = ({ icon: Icon, placeholder, value, onChange, type = "text", className = "" }) => (
  <div className={`relative flex-1 ${className}`}>
    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
      <Icon className="h-5 w-5 text-gray-400" />
    </div>
    <input
      type={type}
      className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
      placeholder={placeholder}
      value={value}
      onChange={onChange}
    />
  </div>
);

// 2. Listing Cards (Hotel, Package)
// Removed FlightCard as it is now in FlightSearchResults component

const HotelCard: React.FC<{ hotel: Hotel }> = ({ hotel }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition">
    <img src={hotel.image} alt={hotel.name} className="w-full h-48 object-cover" />
    <div className="p-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-bold text-lg text-gray-900">{hotel.name}</h3>
          <p className="text-sm text-gray-500 flex items-center gap-1"><MapPin size={14}/> {hotel.location}</p>
        </div>
        <div className="flex items-center bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold">
          {hotel.rating} ★
        </div>
      </div>
      <div className="mt-4 flex justify-between items-end">
        <p className="text-sm text-gray-500">Per Night</p>
        <p className="text-xl font-bold text-blue-600">৳{hotel.pricePerNight.toLocaleString()}</p>
      </div>
      <button className="mt-4 w-full border border-blue-600 text-blue-600 py-2 rounded-lg hover:bg-blue-50 font-medium transition">
        View Details
      </button>
    </div>
  </div>
);

const PackageCard: React.FC<{ pkg: TravelPackage; isUmrah?: boolean; onViewDetails?: (pkg: TravelPackage) => void }> = ({ pkg, isUmrah, onViewDetails }) => (
  <div className={`bg-white rounded-xl shadow-sm border ${isUmrah ? 'border-yellow-200 ring-1 ring-yellow-100' : 'border-gray-100'} overflow-hidden hover:shadow-md transition group h-full flex flex-col`}>
    <div className="relative h-56 overflow-hidden">
      <img src={pkg.image} alt={pkg.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
      <div className={`absolute top-4 left-4 ${isUmrah ? 'bg-yellow-500 text-black' : 'bg-black/60 text-white'} backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium`}>
        {pkg.type}
      </div>
      {pkg.category && (
         <div className="absolute top-4 right-4 bg-white/90 text-slate-800 backdrop-blur-sm px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider">
            {pkg.category}
         </div>
      )}
    </div>
    <div className="p-5 flex flex-col flex-grow">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold text-lg text-gray-900 line-clamp-1">{pkg.title}</h3>
        <span className={`text-xs ${isUmrah ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-700'} px-2 py-1 rounded`}>{pkg.duration}</span>
      </div>
      <div className="flex flex-wrap gap-2 mb-4 flex-grow content-start">
        {pkg.includes.slice(0, 4).map((inc, i) => (
          <span key={i} className="text-xs text-gray-500 border border-gray-200 px-2 py-1 rounded-full flex items-center gap-1">
             <CheckCircle size={10} className={isUmrah ? 'text-yellow-600' : 'text-blue-500'}/> {inc}
          </span>
        ))}
      </div>
      <div className="flex justify-between items-center pt-4 border-t border-gray-100 mt-auto">
        <div className="text-xs text-gray-400">Starting from</div>
        <div className={`text-xl font-bold ${isUmrah ? 'text-yellow-600' : 'text-blue-600'}`}>৳{pkg.price.toLocaleString()}</div>
      </div>
       <button 
         onClick={() => onViewDetails && onViewDetails(pkg)}
         className={`mt-4 w-full ${isUmrah ? 'bg-yellow-500 text-black hover:bg-yellow-400' : 'bg-blue-600 text-white hover:bg-blue-700'} py-2 rounded-lg font-medium transition`}
       >
        View Details
      </button>
    </div>
  </div>
);

// --- MAIN APP COMPONENT ---

const PlaneIcon = ({ className, size }: any) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M2 12h20" />
      <path d="M13 2l9 10-9 10" />
    </svg>
);

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [page, setPage] = useState('home'); // Default to home
  const [searchTab, setSearchTab] = useState<'flight' | 'hotel' | 'visa'>('flight');
  
  // Auth State
  const [loginRole, setLoginRole] = useState<UserRole>(UserRole.CUSTOMER);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginName, setLoginName] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Flight Search State
  const [tripType, setTripType] = useState<'one-way' | 'round-trip' | 'multi-city'>('one-way');
  const [flightFrom, setFlightFrom] = useState('');
  const [flightTo, setFlightTo] = useState('');
  const [flightDate, setFlightDate] = useState('');
  const [flightReturnDate, setFlightReturnDate] = useState('');
  const [searchedFlights, setSearchedFlights] = useState<Flight[]>([]);
  const [isSearchingFlights, setIsSearchingFlights] = useState(false);
  
  // Multi-city State
  const [multiCitySegments, setMultiCitySegments] = useState([
    { from: '', to: '', date: '' },
    { from: '', to: '', date: '' }
  ]);

  // Passenger & Class State
  const [passengers, setPassengers] = useState({ adult: 1, child: 0, infant: 0 });
  const [cabinClass, setCabinClass] = useState('Economy');
  const [showPassengerDropdown, setShowPassengerDropdown] = useState(false);
  const passengerDropdownRef = useRef<HTMLDivElement>(null);

  // Data State
  const [allBookings, setAllBookings] = useState<Booking[]>(MOCK_BOOKINGS);
  const [bookingStatusFilter, setBookingStatusFilter] = useState<'ALL' | 'CONFIRMED' | 'PENDING' | 'CANCELLED'>('ALL');
  const [bookingStartDate, setBookingStartDate] = useState('');
  const [bookingEndDate, setBookingEndDate] = useState('');
  const [selectedPackage, setSelectedPackage] = useState<TravelPackage | null>(null);
  
  // Admin Data State
  const [managedFlights, setManagedFlights] = useState<Flight[]>(MOCK_FLIGHTS);
  const [newFlight, setNewFlight] = useState({ airline: '', flightNumber: '', from: '', to: '', price: '', departureTime: '', arrivalTime: '' });

  // AI State (Pop-up)
  const [showAIPlanner, setShowAIPlanner] = useState(false);
  const [aiTab, setAiTab] = useState<'plan' | 'chat'>('plan');
  const [aiDestination, setAiDestination] = useState('');
  const [aiDays, setAiDays] = useState(5);
  const [aiBudget, setAiBudget] = useState('50000 BDT');
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<{role: 'user'|'bot', text: string}[]>([]);

  // Agent State (Synced with Backend)
  const [markup, setMarkup] = useState(0); 
  const [walletMode, setWalletMode] = useState<'view' | 'deposit' | 'withdraw'>('view');
  const [transAmount, setTransAmount] = useState('');
  const [isWalletLoading, setIsWalletLoading] = useState(false);

  // Profile Edit State
  const [profileName, setProfileName] = useState('');
  const [profileEmail, setProfileEmail] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  // UI States
  const [tourCategoryFilter, setTourCategoryFilter] = useState<'ALL' | 'DOMESTIC' | 'INTERNATIONAL'>('ALL');

  // --- API HELPERS ---
  const authHeaders = () => ({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  });

  // --- EFFECTS ---
  useEffect(() => {
    // If we have a token but no user object (e.g. refresh), we might want to validate or just logout.
    // For this simple demo, we rely on the login response to set user.
    if (!token && page !== 'login' && page !== 'register' && page !== 'home' && !['flights', 'hotels', 'packages', 'visa', 'package-details'].includes(page)) {
        setPage('home');
    }
  }, [token, page]);

  // Sync page state with register toggle
  useEffect(() => {
    if (page === 'register') setIsRegistering(true);
    if (page === 'login') setIsRegistering(false);
  }, [page]);

  useEffect(() => {
    if (user?.role === UserRole.AGENT && (page === 'dashboard' || page === 'wallet')) {
        fetchWalletData();
    }
  }, [user, page]);

  // Sync profile state when user loads
  useEffect(() => {
    if (user) {
        setProfileName(user.name);
        setProfileEmail(user.email);
    }
  }, [user]);
  
  // Close passenger dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (passengerDropdownRef.current && !passengerDropdownRef.current.contains(event.target as Node)) {
        setShowPassengerDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const fetchWalletData = async () => {
    if (!token) return;
    try {
        const res = await fetch(`${API_URL}/agent/wallet`, { headers: authHeaders() });
        if (res.ok) {
            const data = await res.json();
            setUser(prev => prev ? { ...prev, balance: data.balance, markup: data.markup } : null);
            setMarkup(data.markup || 0);
        }
    } catch (err) {
        console.error("Failed to fetch wallet data", err);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError('');

    const endpoint = isRegistering ? '/auth/register' : '/auth/login';
    const body = isRegistering 
        ? { name: loginName, email: loginEmail, password: loginPass, role: loginRole }
        : { email: loginEmail, password: loginPass, role: loginRole };

    try {
        const res = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        
        const data = await res.json();

        if (res.ok) {
            setToken(data.token);
            localStorage.setItem('token', data.token);
            setUser(data.user);
            setPage(loginRole === UserRole.CUSTOMER ? 'home' : 'dashboard');
        } else {
            setLoginError(data.message || 'Authentication failed');
        }
    } catch (err) {
        setLoginError('Network error. Is the server running?');
    } finally {
        setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    setPage('home');
    setLoginEmail('');
    setLoginPass('');
    setLoginName('');
    setLoginError('');
    setIsRegistering(false);
    setBookingStartDate('');
    setBookingEndDate('');
  };
  
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsUpdatingProfile(true);

    try {
      const res = await fetch(`${API_URL}/auth/profile`, {
        method: 'PUT',
        headers: authHeaders(),
        body: JSON.stringify({ name: profileName, email: profileEmail })
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data.user);
        alert('Profile updated successfully!');
      } else {
        alert(data.message || 'Failed to update profile');
      }
    } catch (err) {
      alert('Network error');
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsUpdatingProfile(true);

    try {
      const res = await fetch(`${API_URL}/auth/change-password`, {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ currentPassword, newPassword })
      });
      const data = await res.json();
      if (res.ok) {
        alert('Password changed successfully!');
        setCurrentPassword('');
        setNewPassword('');
      } else {
        alert(data.message || 'Failed to change password');
      }
    } catch (err) {
      alert('Network error');
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const handleCancelBooking = (id: string) => {
    if (confirm('Are you sure you want to cancel this booking? Cancellation charges may apply.')) {
      setAllBookings(prev => prev.map(b => 
        b.id === id ? { ...b, status: 'CANCELLED' } : b
      ));
    }
  };

  const handleConfirmBooking = (id: string) => {
     if (confirm('Confirm this booking?')) {
      setAllBookings(prev => prev.map(b => 
        b.id === id ? { ...b, status: 'CONFIRMED' } : b
      ));
    }
  };

  const handleAddFlight = (e: React.FormEvent) => {
      e.preventDefault();
      const flight: Flight = {
          id: `F-${Date.now()}`,
          airline: newFlight.airline,
          flightNumber: newFlight.flightNumber,
          from: newFlight.from.toUpperCase(),
          to: newFlight.to.toUpperCase(),
          departureTime: newFlight.departureTime,
          arrivalTime: newFlight.arrivalTime,
          price: Number(newFlight.price),
          logo: 'https://picsum.photos/40/40?random=' + Math.floor(Math.random() * 100)
      };
      setManagedFlights([...managedFlights, flight]);
      setNewFlight({ airline: '', flightNumber: '', from: '', to: '', price: '', departureTime: '', arrivalTime: '' });
      alert("Flight Added Successfully");
  };

  const handleDeleteFlight = (id: string) => {
      if(confirm('Delete this flight route?')) {
          setManagedFlights(managedFlights.filter(f => f.id !== id));
      }
  }
  
  const handleViewDetails = (booking: Booking) => {
      alert(`BOOKING DETAILS\n------------------\nID: ${booking.id}\nService: ${booking.details}\nType: ${booking.type}\nAmount: ৳${booking.amount.toLocaleString()}\nStatus: ${booking.status}\nDate: ${booking.date}`);
  };

  // --- Search Handlers ---

  const handleMultiCityChange = (index: number, field: string, value: string) => {
    const newSegments = [...multiCitySegments];
    newSegments[index] = { ...newSegments[index], [field]: value };
    setMultiCitySegments(newSegments);
  };

  const addMultiCitySegment = () => {
    if (multiCitySegments.length < 5) {
       setMultiCitySegments([...multiCitySegments, { from: '', to: '', date: '' }]);
    }
  };

  const removeMultiCitySegment = (index: number) => {
    if (multiCitySegments.length > 2) {
       setMultiCitySegments(multiCitySegments.filter((_, i) => i !== index));
    }
  };

  const updatePassenger = (type: 'adult'|'child'|'infant', delta: number) => {
    setPassengers(prev => {
        const newValue = prev[type] + delta;
        if (newValue < 0) return prev;
        if (type === 'adult' && newValue < 1) return prev; // Min 1 adult
        return { ...prev, [type]: newValue };
    });
  };

  const getTotalPassengers = () => passengers.adult + passengers.child + passengers.infant;

  // Flight Search Function
  const handleFlightSearch = async () => {
    
    // Basic Validation based on Trip Type
    if (tripType === 'one-way' || tripType === 'round-trip') {
       if (!flightFrom || !flightTo || !flightDate) {
         alert("Please select origin, destination and date.");
         return;
       }
       if (tripType === 'round-trip' && !flightReturnDate) {
          alert("Please select a return date.");
          return;
       }
    } else if (tripType === 'multi-city') {
       const isValid = multiCitySegments.every(seg => seg.from && seg.to && seg.date);
       if (!isValid) {
          alert("Please fill in all city segments.");
          return;
       }
    }
    
    setIsSearchingFlights(true);
    setPage('flights');
    setSearchedFlights([]); // Clear previous

    try {
      const commonPayload = {
        passengers,
        cabinClass,
        tripType
      };

      const searchPayload = tripType === 'multi-city' 
        ? { segments: multiCitySegments, ...commonPayload } 
        : { from: flightFrom, to: flightTo, date: flightDate, returnDate: flightReturnDate, ...commonPayload };

      const res = await fetch(`${API_URL}/flights/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(searchPayload)
      });
      
      const data = await res.json();
      if (data.success) {
        setSearchedFlights(data.data);
      } else {
        alert("No flights found.");
      }
    } catch (error) {
      console.error("Search failed", error);
      alert("Search failed. Ensure backend is running.");
    } finally {
      setIsSearchingFlights(false);
    }
  };

  // AI Functions
  const handleAIPlan = async () => {
    if(!aiDestination) return;
    setAiLoading(true);
    const itinerary = await generateTravelItinerary(aiDestination, aiDays, aiBudget);
    setAiResult(itinerary);
    setAiLoading(false);
  };

  const handleAIChat = async () => {
    if(!chatInput) return;
    const userMsg = chatInput;
    setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
    setChatInput('');
    setAiLoading(true); 
    
    const botResponse = await askTravelAssistant(userMsg);
    setChatHistory(prev => [...prev, { role: 'bot', text: botResponse }]);
    setAiLoading(false);
  }

  const handleTransaction = async () => {
    if (!user || !token) return;
    const amount = parseInt(transAmount);
    if (isNaN(amount) || amount <= 0) {
        alert("Please enter a valid amount");
        return;
    }

    setIsWalletLoading(true);
    try {
        const endpoint = walletMode === 'deposit' ? '/agent/wallet/deposit' : '/agent/wallet/withdraw';
        const res = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ amount })
        });
        
        const data = await res.json();
        
        if (res.ok) {
            setUser(prev => prev ? { ...prev, balance: data.newBalance } : null);
            alert(`Success: ${data.message}`);
            setWalletMode('view');
            setTransAmount('');
        } else {
            alert(`Error: ${data.message}`);
        }
    } catch (err) {
        alert("Transaction failed due to network error.");
    } finally {
        setIsWalletLoading(false);
    }
  };
  
  const handleMarkupSave = async () => {
    if (!token) return;
    try {
        const res = await fetch(`${API_URL}/agent/wallet/config`, {
            method: 'POST',
            headers: authHeaders(),
            body: JSON.stringify({ markup })
        });
        if (res.ok) {
            alert("Markup configuration saved!");
            setUser(prev => prev ? { ...prev, markup } : null);
        } else {
            alert("Failed to save markup.");
        }
    } catch (e) {
        alert("Network error saving markup");
    }
  }

  // Handle page navigation override for AI Planner
  const handleNavigate = (p: string) => {
    if (p === 'ai-planner') {
      setShowAIPlanner(true);
    } else {
      setPage(p);
    }
  };

  const handleViewPackageDetails = (pkg: TravelPackage) => {
      setSelectedPackage(pkg);
      setPage('package-details');
      window.scrollTo(0, 0);
  };

  // --- PAGES RENDERERS ---

  const renderAIPlannerPopup = () => (
    <div className={`fixed bottom-24 right-4 md:right-8 w-[90vw] md:w-96 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 overflow-hidden flex flex-col transition-all duration-300 origin-bottom-right ${showAIPlanner ? 'scale-100 opacity-100' : 'scale-0 opacity-0 pointer-events-none'}`} style={{ maxHeight: 'calc(100vh - 120px)' }}>
       {/* Header */}
       <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-4 text-white flex justify-between items-center">
          <div className="flex items-center gap-2 font-bold">
            <Bot size={20} className="text-purple-100"/> AI Travel Assistant
          </div>
          <button onClick={() => setShowAIPlanner(false)} className="hover:bg-white/20 p-1 rounded-full transition"><X size={18}/></button>
       </div>
       
       {/* Tabs */}
       <div className="flex border-b border-gray-100">
          <button onClick={() => setAiTab('plan')} className={`flex-1 py-3 text-sm font-medium transition ${aiTab === 'plan' ? 'text-purple-600 border-b-2 border-purple-600 bg-purple-50/50' : 'text-gray-500 hover:bg-gray-50'}`}>Plan Trip</button>
          <button onClick={() => setAiTab('chat')} className={`flex-1 py-3 text-sm font-medium transition ${aiTab === 'chat' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50' : 'text-gray-500 hover:bg-gray-50'}`}>Chat Assistant</button>
       </div>

       {/* Content */}
       <div className="flex-1 overflow-y-auto p-4 bg-gray-50 min-h-[400px]">
          {aiTab === 'plan' ? (
             <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Destination</label>
                  <input className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none" placeholder="Where to?" value={aiDestination} onChange={(e) => setAiDestination(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                   <div>
                      <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Days</label>
                      <input type="number" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none" value={aiDays} onChange={(e) => setAiDays(parseInt(e.target.value))} />
                   </div>
                   <div>
                      <label className="text-xs font-bold text-gray-500 uppercase mb-1 block">Budget</label>
                      <input className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none" value={aiBudget} onChange={(e) => setAiBudget(e.target.value)} />
                   </div>
                </div>
                <button 
                  onClick={handleAIPlan}
                  disabled={aiLoading || !aiDestination}
                  className="w-full bg-purple-600 text-white font-bold py-2.5 rounded-lg hover:bg-purple-700 transition flex justify-center items-center gap-2 disabled:opacity-70 text-sm"
                >
                   {aiLoading ? <Loader2 className="animate-spin" size={16}/> : <><Sparkles size={16}/> Generate Plan</>}
                </button>
                {aiResult && (
                   <div className="mt-4 p-3 bg-white rounded-lg text-xs text-gray-700 whitespace-pre-wrap border border-gray-200 shadow-sm max-h-60 overflow-y-auto">
                      {aiResult}
                   </div>
                )}
             </div>
          ) : (
             <div className="flex flex-col h-full h-[400px]">
                <div className="flex-1 overflow-y-auto space-y-3 mb-3 pr-1">
                   {chatHistory.length === 0 && (
                      <div className="text-center text-gray-400 mt-20">
                         <Bot size={32} className="mx-auto mb-2 opacity-30"/>
                         <p className="text-xs">Ask about flights, visas, or anything!</p>
                      </div>
                   )}
                   {chatHistory.map((msg, idx) => (
                      <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                         <div className={`max-w-[85%] px-3 py-2 rounded-lg text-xs ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm'}`}>
                            {msg.text}
                         </div>
                      </div>
                   ))}
                   {aiLoading && (
                       <div className="flex justify-start">
                          <div className="bg-white border border-gray-200 p-2 rounded-lg rounded-bl-none shadow-sm">
                             <Loader2 className="animate-spin h-3 w-3 text-gray-400"/>
                          </div>
                       </div>
                   )}
                </div>
                <div className="flex gap-2 pt-2 border-t border-gray-200">
                   <input 
                      className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      placeholder="Ask something..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleAIChat()}
                   />
                   <button onClick={handleAIChat} disabled={!chatInput || aiLoading} className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50">
                      <Send size={16}/>
                   </button>
                </div>
             </div>
          )}
       </div>
    </div>
  );

  const renderHome = () => {
    // Filter packages based on category
    const filteredPackages = MOCK_PACKAGES.filter(pkg => {
        if (tourCategoryFilter === 'ALL') return true;
        return pkg.category === tourCategoryFilter;
    });

    return (
    <div className="space-y-16 pb-16 relative">
      {/* Hero Section */}
      <div className="relative bg-slate-900 h-[650px] flex items-center justify-center transition-all duration-500">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=2000&q=80" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-60"
          />
        </div>
        
        <div className="relative z-10 w-full max-w-6xl px-4 mt-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white text-center mb-8 drop-shadow-md leading-tight">
            Explore the World with <br/> <span className="text-blue-300">SkyBound Technology</span>
          </h1>
          
          {/* Search Box */}
          <div className="bg-white rounded-2xl shadow-xl overflow-visible relative z-20">
            <div className="flex border-b border-gray-100 overflow-x-auto rounded-t-2xl">
              <SearchTab active={searchTab === 'flight'} label="Flights" icon={PlaneIcon} onClick={() => setSearchTab('flight')} />
              <SearchTab active={searchTab === 'hotel'} label="Hotels" icon={Building} onClick={() => setSearchTab('hotel')} />
              <SearchTab active={searchTab === 'visa'} label="Visa" icon={MapPin} onClick={() => setSearchTab('visa')} />
            </div>
            
            <div className="p-6">
              {searchTab === 'flight' && (
                <div className="space-y-4">
                  {/* Trip Type Toggles */}
                  <div className="flex items-center gap-6 mb-4 text-sm font-medium text-gray-700">
                      <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                              type="radio" 
                              name="tripType" 
                              checked={tripType === 'one-way'} 
                              onChange={() => setTripType('one-way')}
                              className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                          />
                          One Way
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                              type="radio" 
                              name="tripType" 
                              checked={tripType === 'round-trip'} 
                              onChange={() => setTripType('round-trip')}
                              className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                          />
                          Round Trip
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                          <input 
                              type="radio" 
                              name="tripType" 
                              checked={tripType === 'multi-city'} 
                              onChange={() => setTripType('multi-city')}
                              className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                          />
                          Multi City
                      </label>
                  </div>

                  {/* Standard Search (One Way / Round Trip) */}
                  {tripType !== 'multi-city' && (
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-2">
                        <div className="md:col-span-3">
                            <SearchInput 
                                icon={MapPin} 
                                placeholder="From (DAC)" 
                                value={flightFrom} 
                                onChange={(e) => setFlightFrom(e.target.value.toUpperCase())} 
                            />
                        </div>
                        <div className="md:col-span-3">
                            <SearchInput 
                                icon={MapPin} 
                                placeholder="To (CXB, DXB)" 
                                value={flightTo} 
                                onChange={(e) => setFlightTo(e.target.value.toUpperCase())}
                            />
                        </div>
                        <div className={`md:col-span-${tripType === 'round-trip' ? '2' : '3'}`}>
                             <SearchInput 
                                icon={Calendar} 
                                placeholder="Departure" 
                                type="date" 
                                value={flightDate}
                                onChange={(e) => setFlightDate(e.target.value)}
                              />
                        </div>
                        {tripType === 'round-trip' && (
                             <div className="md:col-span-2">
                                <SearchInput 
                                    icon={Calendar} 
                                    placeholder="Return" 
                                    type="date" 
                                    value={flightReturnDate}
                                    onChange={(e) => setFlightReturnDate(e.target.value)}
                                />
                             </div>
                        )}
                        
                        {/* Passenger & Class Dropdown Trigger */}
                        <div className="md:col-span-3 relative" ref={passengerDropdownRef}>
                           <div 
                              onClick={() => setShowPassengerDropdown(!showPassengerDropdown)}
                              className="w-full h-full border border-gray-300 rounded-lg px-4 py-3 flex items-center justify-between cursor-pointer bg-white hover:border-blue-500"
                           >
                              <div className="flex flex-col items-start leading-tight">
                                <span className="text-xs text-gray-400 font-bold uppercase">Travelers & Class</span>
                                <span className="text-sm font-bold text-gray-800">
                                   {getTotalPassengers()} Person, {cabinClass}
                                </span>
                              </div>
                              <ChevronDown size={16} className="text-gray-400"/>
                           </div>

                           {/* Dropdown Content */}
                           {showPassengerDropdown && (
                              <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 p-4 animate-in slide-in-from-top-2 duration-200">
                                  {/* Cabin Class */}
                                  <div className="mb-4">
                                     <label className="text-xs font-bold text-gray-500 uppercase mb-2 block">Cabin Class</label>
                                     <div className="grid grid-cols-3 gap-2">
                                        {['Economy', 'Business', 'First'].map(cls => (
                                           <button 
                                              key={cls}
                                              onClick={() => setCabinClass(cls)}
                                              className={`text-xs py-1.5 rounded border transition ${cabinClass === cls ? 'bg-blue-600 text-white border-blue-600' : 'border-gray-200 hover:bg-gray-50'}`}
                                           >
                                              {cls}
                                           </button>
                                        ))}
                                     </div>
                                  </div>
                                  
                                  <hr className="border-gray-100 mb-4"/>

                                  {/* Passenger Counters */}
                                  <div className="space-y-4">
                                     {[
                                         { type: 'adult', label: 'Adults', sub: '12+ yrs' },
                                         { type: 'child', label: 'Children', sub: '2-11 yrs' },
                                         { type: 'infant', label: 'Infants', sub: '< 2 yrs' }
                                     ].map((p) => (
                                         <div key={p.type} className="flex justify-between items-center">
                                            <div>
                                               <p className="font-bold text-sm text-gray-800">{p.label}</p>
                                               <p className="text-xs text-gray-400">{p.sub}</p>
                                            </div>
                                            <div className="flex items-center gap-3">
                                               <button 
                                                  onClick={() => updatePassenger(p.type as any, -1)}
                                                  className={`p-1 rounded-full border ${passengers[p.type as keyof typeof passengers] === 0 ? 'text-gray-300 border-gray-200' : 'text-blue-600 border-blue-200 hover:bg-blue-50'}`}
                                                  disabled={p.type === 'adult' && passengers.adult <= 1}
                                               >
                                                  <Minus size={14}/>
                                               </button>
                                               <span className="w-4 text-center font-bold text-sm">{passengers[p.type as keyof typeof passengers]}</span>
                                               <button 
                                                  onClick={() => updatePassenger(p.type as any, 1)}
                                                  className="p-1 rounded-full border border-blue-200 text-blue-600 hover:bg-blue-50"
                                               >
                                                  <Plus size={14}/>
                                               </button>
                                            </div>
                                         </div>
                                     ))}
                                  </div>

                                  <button 
                                     onClick={() => setShowPassengerDropdown(false)}
                                     className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg text-sm font-bold hover:bg-blue-700"
                                  >
                                     Done
                                  </button>
                              </div>
                           )}
                        </div>
                    </div>
                  )}

                  {/* Search Button */}
                  <div className="flex justify-center mt-6">
                    <button onClick={handleFlightSearch} className="bg-blue-600 text-white font-bold py-3.5 px-12 rounded-xl hover:bg-blue-700 transition flex items-center justify-center gap-2 shadow-lg shadow-blue-200 transform hover:-translate-y-0.5 w-full md:w-auto">
                        {isSearchingFlights ? <Loader2 className="animate-spin" size={20}/> : <><Search size={20}/> Search Flights</>}
                    </button>
                  </div>
                </div>
              )}
              {searchTab === 'hotel' && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="col-span-2">
                    <SearchInput icon={MapPin} placeholder="Destination or Hotel Name" />
                  </div>
                  <SearchInput icon={Calendar} placeholder="Check-in" type="date" />
                  <button onClick={() => setPage('hotels')} className="bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition">
                    Search Hotels
                  </button>
                </div>
              )}
               {searchTab === 'visa' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="col-span-2">
                     <SearchInput icon={MapPin} placeholder="Which country do you want to visit?" />
                  </div>
                  <button onClick={() => setPage('visa')} className="bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition">
                    Check Visa Info
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Destinations Section */}
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Top Destinations</h2>
        <p className="text-gray-500 mb-8">Explore the most popular travel destinations around the world.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {MOCK_DESTINATIONS.map((dest, idx) => (
            <div key={idx} className="group relative rounded-xl overflow-hidden shadow-sm cursor-pointer h-64">
              <img src={dest.image} alt={dest.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-xl font-bold">{dest.name}</h3>
                  <p className="text-sm opacity-90">Flights from ৳{dest.price.toLocaleString()}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tour Packages Section (Enhanced) */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
           <div>
             <h2 className="text-3xl font-bold text-gray-900">Exclusive Tour Packages</h2>
             <p className="text-gray-500 mt-2">Discover curated holiday experiences, from local getaways to international adventures.</p>
           </div>
           
           {/* Filter Tabs */}
           <div className="flex bg-gray-100 p-1 rounded-lg">
              <button 
                onClick={() => setTourCategoryFilter('ALL')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition ${tourCategoryFilter === 'ALL' ? 'bg-white shadow text-blue-600' : 'text-gray-600 hover:text-gray-900'}`}
              >
                All
              </button>
              <button 
                onClick={() => setTourCategoryFilter('DOMESTIC')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition ${tourCategoryFilter === 'DOMESTIC' ? 'bg-white shadow text-blue-600' : 'text-gray-600 hover:text-gray-900'}`}
              >
                Domestic
              </button>
              <button 
                onClick={() => setTourCategoryFilter('INTERNATIONAL')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition ${tourCategoryFilter === 'INTERNATIONAL' ? 'bg-white shadow text-blue-600' : 'text-gray-600 hover:text-gray-900'}`}
              >
                International
              </button>
           </div>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredPackages.map(pkg => <PackageCard key={pkg.id} pkg={pkg} onViewDetails={handleViewPackageDetails} />)}
        </div>
        
        {filteredPackages.length === 0 && (
            <div className="text-center py-12 text-gray-500 bg-gray-50 rounded-xl border border-dashed border-gray-300">
                <p>No packages found for this category.</p>
            </div>
        )}

        <div className="text-center mt-10">
             <button onClick={() => setPage('packages')} className="inline-flex items-center gap-2 text-blue-600 font-bold hover:text-blue-800 hover:underline">
                View All Packages <ArrowRight size={16}/>
             </button>
        </div>
      </div>

      {/* Umrah Packages Section */}
      <div className="bg-yellow-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
             <span className="bg-yellow-100 text-yellow-800 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">Spiritual Journey</span>
             <h2 className="text-3xl font-bold text-gray-900 mt-2">Umrah Packages 2024</h2>
             <p className="text-gray-600 mt-2 max-w-2xl mx-auto">Perform your Umrah with peace of mind. We provide comprehensive packages including visa, flight, and accommodation near Haram.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {MOCK_UMRAH_PACKAGES.map(pkg => <PackageCard key={pkg.id} pkg={pkg} isUmrah onViewDetails={handleViewPackageDetails} />)}
          </div>
          <div className="text-center mt-10">
             <button onClick={() => setPage('packages')} className="inline-flex items-center gap-2 text-yellow-700 font-bold hover:text-yellow-800 hover:underline">
                View All Umrah Packages <ArrowRight size={16}/>
             </button>
          </div>
        </div>
      </div>

      {/* About Us Section */}
      <div className="bg-white py-16">
         <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
               <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1742&q=80" alt="Team meeting" className="rounded-2xl shadow-xl w-full object-cover h-[400px]"/>
               <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-xl shadow-lg hidden md:block">
                  <p className="text-4xl font-bold">10+</p>
                  <p className="text-sm opacity-90">Years of Experience</p>
               </div>
            </div>
            <div>
               <h2 className="text-3xl font-bold text-gray-900 mb-6">About SkyBound Travel</h2>
               <p className="text-gray-600 mb-6 leading-relaxed">
                  SkyBound Travel Technology is Bangladesh's leading travel solutions provider. 
                  We combine cutting-edge technology with personalized service to create unforgettable travel experiences.
                  Whether you are planning a corporate trip, a family holiday, or a spiritual Umrah journey, 
                  our team is dedicated to ensuring every detail is perfect.
               </p>
               <div className="grid grid-cols-2 gap-6 mb-8">
                  <div>
                     <h4 className="text-2xl font-bold text-blue-600">5000+</h4>
                     <p className="text-sm text-gray-500">Happy Travelers</p>
                  </div>
                  <div>
                     <h4 className="text-2xl font-bold text-blue-600">100+</h4>
                     <p className="text-sm text-gray-500">Global Partners</p>
                  </div>
                  <div>
                     <h4 className="text-2xl font-bold text-blue-600">24/7</h4>
                     <p className="text-sm text-gray-500">Customer Support</p>
                  </div>
                  <div>
                     <h4 className="text-2xl font-bold text-blue-600">50+</h4>
                     <p className="text-sm text-gray-500">Destinations</p>
                  </div>
               </div>
               <button className="bg-slate-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-slate-800 transition">
                  Learn More About Us
               </button>
            </div>
         </div>
      </div>

      {/* Our Team Section */}
      <div className="max-w-7xl mx-auto px-4">
         <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900">Meet Our Team</h2>
            <p className="text-gray-500 mt-2">The dedicated professionals behind your seamless journeys.</p>
         </div>
         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {MOCK_TEAM.map((member, idx) => (
               <div key={idx} className="text-center group">
                  <div className="relative w-48 h-48 mx-auto mb-4 overflow-hidden rounded-full border-4 border-white shadow-lg">
                     <img src={member.image} alt={member.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-500"/>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{member.name}</h3>
                  <p className="text-blue-600 text-sm font-medium">{member.role}</p>
               </div>
            ))}
         </div>
      </div>
      
       {/* Why Choose Us */}
      <div className="bg-blue-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Why Book With SkyBound?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="p-6 bg-white rounded-xl shadow-sm">
                   <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4"><CheckCircle /></div>
                   <h3 className="font-bold mb-2">Best Price Guarantee</h3>
                   <p className="text-sm text-gray-500">We ensure the best market rates for flights and hotels.</p>
                </div>
                <div className="p-6 bg-white rounded-xl shadow-sm">
                   <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto mb-4"><Users /></div>
                   <h3 className="font-bold mb-2">24/7 Support</h3>
                   <p className="text-sm text-gray-500">Our dedicated team is always available to help you.</p>
                </div>
                <div className="p-6 bg-white rounded-xl shadow-sm">
                   <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4"><DollarSign /></div>
                   <h3 className="font-bold mb-2">Secure Payments</h3>
                   <p className="text-sm text-gray-500">Pay safely with SSLCommerz, bKash, and Credit Cards.</p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
  };

  const renderPackageDetails = () => {
    if (!selectedPackage) return null;
    const isUmrah = selectedPackage.type === 'UMRAH';
    const accentColor = isUmrah ? 'yellow' : 'blue';
    const textColor = isUmrah ? 'text-yellow-700' : 'text-blue-600';
    const bgColor = isUmrah ? 'bg-yellow-50' : 'bg-blue-50';
    const btnColor = isUmrah ? 'bg-yellow-500 hover:bg-yellow-400 text-black' : 'bg-blue-600 hover:bg-blue-700 text-white';

    return (
        <div className="pb-16 bg-gray-50">
            {/* Header / Hero */}
            <div className="relative h-[400px]">
                <img src={selectedPackage.image} alt={selectedPackage.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 w-full p-8 text-white">
                    <div className="max-w-7xl mx-auto">
                        <button onClick={() => setPage('home')} className="mb-4 flex items-center gap-2 text-sm hover:text-gray-300 transition w-fit"><ArrowLeft size={16}/> Back to Packages</button>
                        <div className="flex flex-col md:flex-row justify-between items-end gap-4">
                            <div>
                                <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold mb-3 ${isUmrah ? 'bg-yellow-500 text-black' : 'bg-blue-600 text-white'}`}>
                                    {selectedPackage.type} PACKAGE
                                </span>
                                <h1 className="text-4xl font-bold mb-2">{selectedPackage.title}</h1>
                                <p className="opacity-90 flex items-center gap-2"><Clock size={18}/> {selectedPackage.duration}</p>
                            </div>
                            <div className="text-right">
                                <p className="text-sm opacity-80 mb-1">Starting Price</p>
                                <p className="text-3xl font-bold text-white">৳{selectedPackage.price.toLocaleString()}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Content */}
                <div className="lg:col-span-2 space-y-8">
                    {/* Overview */}
                    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                        <h2 className="text-xl font-bold text-gray-900 mb-4">Package Overview</h2>
                        <p className="text-gray-600 leading-relaxed">
                            {selectedPackage.description || "Experience a wonderful journey with our meticulously planned package. We ensure top-notch service, comfortable accommodation, and seamless transport."}
                        </p>
                    </div>

                    {/* Itinerary */}
                    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                        <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                            <MapIcon className={textColor} size={20}/> Daily Itinerary
                        </h2>
                        <div className="space-y-6 relative border-l-2 border-gray-100 ml-3 pl-8 pb-2">
                            {selectedPackage.itineraryList ? selectedPackage.itineraryList.map((day, idx) => (
                                <div key={idx} className="relative">
                                    <div className={`absolute -left-[41px] top-0 w-6 h-6 rounded-full border-4 border-white ${isUmrah ? 'bg-yellow-500' : 'bg-blue-600'}`}></div>
                                    <h3 className="font-bold text-gray-900 text-lg">Day {day.day}: {day.title}</h3>
                                    <p className="text-gray-600 mt-2 text-sm leading-relaxed">{day.desc}</p>
                                </div>
                            )) : (
                                <p className="text-gray-500 italic">Detailed itinerary coming soon.</p>
                            )}
                        </div>
                    </div>

                    {/* Hotel Details (Specific for Umrah mostly) */}
                    {selectedPackage.hotelDetails && (
                        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                                <HotelIcon className={textColor} size={20}/> Accommodation Details
                            </h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {selectedPackage.hotelDetails.map((hotel, idx) => (
                                    <div key={idx} className={`${bgColor} p-4 rounded-lg border ${isUmrah ? 'border-yellow-100' : 'border-blue-100'}`}>
                                        <h4 className="font-bold text-gray-900 mb-1">{hotel.name}</h4>
                                        <div className="flex items-center gap-1 text-yellow-500 mb-2 text-xs">
                                            {[...Array(hotel.stars)].map((_, i) => <Star key={i} size={12} fill="currentColor"/>)}
                                            <span className="text-gray-500 ml-1">({hotel.stars} Star)</span>
                                        </div>
                                        <p className="text-sm text-gray-600 flex items-center gap-1"><MapPin size={14}/> {hotel.location}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 sticky top-24">
                        <h3 className="font-bold text-lg mb-4 text-gray-900">Book This Package</h3>
                        <div className="space-y-3 mb-6">
                            <div className="flex justify-between text-sm py-2 border-b border-gray-100">
                                <span className="text-gray-600">Base Price</span>
                                <span className="font-bold">৳{selectedPackage.price.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between text-sm py-2 border-b border-gray-100">
                                <span className="text-gray-600">Visa Fee</span>
                                <span className="text-green-600 font-medium">Included</span>
                            </div>
                            <div className="flex justify-between text-lg pt-2">
                                <span className="font-bold text-gray-900">Total</span>
                                <span className={`font-bold ${textColor}`}>৳{selectedPackage.price.toLocaleString()}</span>
                            </div>
                        </div>
                        
                        <div className="space-y-4 mb-6">
                            <h4 className="font-semibold text-sm text-gray-800">Package Inclusions</h4>
                            <div className="grid grid-cols-2 gap-2">
                                {selectedPackage.includes.map((inc, i) => (
                                    <span key={i} className="text-xs text-gray-600 flex items-center gap-1.5">
                                        <CheckCircle size={12} className={isUmrah ? 'text-yellow-600' : 'text-green-600'}/> {inc}
                                    </span>
                                ))}
                            </div>
                        </div>

                        <button className={`w-full py-3 rounded-lg font-bold shadow-lg transition transform hover:-translate-y-0.5 ${btnColor}`} onClick={() => alert("Booking Request Submitted! Our team will contact you.")}>
                            Book Now
                        </button>
                        <p className="text-xs text-center text-gray-400 mt-4">No payment required immediately.</p>
                    </div>

                    <div className={`rounded-xl p-6 border ${isUmrah ? 'bg-yellow-50 border-yellow-200' : 'bg-blue-50 border-blue-200'}`}>
                        <h3 className={`font-bold mb-2 ${textColor}`}>Need Help?</h3>
                        <p className="text-sm text-gray-600 mb-4">Talk to our expert consultants for customization.</p>
                        <button className="flex items-center justify-center gap-2 w-full bg-white border border-gray-300 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 text-gray-700">
                            <MessageSquare size={16}/> Chat with Us
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
  };

  return (
    <Layout user={user} onLogout={handleLogout} currentPage={page} onNavigate={handleNavigate}>
      {page === 'home' && renderHome()}
      {/* AI Popup Widget - Rendered at App level so it overlays everything */}
      {renderAIPlannerPopup()}

      {page === 'package-details' && renderPackageDetails()}

      {page === 'login' && (
        <div className="max-w-md mx-auto mt-20 bg-white p-8 rounded-xl shadow-lg border border-gray-100">
          <h2 className="text-2xl font-bold mb-6 text-center">Log In to SkyBound</h2>
          {loginError && <div className="bg-red-50 text-red-600 p-3 rounded mb-4 text-sm flex items-center gap-2"><AlertCircle size={16}/>{loginError}</div>}
          <form onSubmit={handleAuthSubmit} className="space-y-4">
             <SearchInput icon={Mail} placeholder="Email Address" type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} />
             <SearchInput icon={Lock} placeholder="Password" type="password" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} />
             <button disabled={isLoggingIn} className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition flex justify-center">
                {isLoggingIn ? <Loader2 className="animate-spin"/> : 'Log In'}
             </button>
          </form>
          <p className="mt-4 text-center text-sm text-gray-500">
             Don't have an account? <button onClick={() => setPage('register')} className="text-blue-600 font-bold hover:underline">Sign Up</button>
          </p>
        </div>
      )}
      {page === 'register' && (
        <div className="max-w-md mx-auto mt-20 bg-white p-8 rounded-xl shadow-lg border border-gray-100">
          <h2 className="text-2xl font-bold mb-6 text-center">Create Account</h2>
          {loginError && <div className="bg-red-50 text-red-600 p-3 rounded mb-4 text-sm flex items-center gap-2"><AlertCircle size={16}/>{loginError}</div>}
          <form onSubmit={handleAuthSubmit} className="space-y-4">
             <SearchInput icon={UserIcon} placeholder="Full Name" value={loginName} onChange={(e) => setLoginName(e.target.value)} />
             <SearchInput icon={Mail} placeholder="Email Address" type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} />
             <SearchInput icon={Lock} placeholder="Password" type="password" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} />
             
             <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Account Type</label>
                <div className="grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => setLoginRole(UserRole.CUSTOMER)} className={`py-2 rounded border text-sm font-medium ${loginRole === UserRole.CUSTOMER ? 'bg-blue-600 text-white border-blue-600' : 'bg-gray-50 text-gray-600 border-gray-200'}`}>Customer</button>
                    <button type="button" onClick={() => setLoginRole(UserRole.AGENT)} className={`py-2 rounded border text-sm font-medium ${loginRole === UserRole.AGENT ? 'bg-blue-600 text-white border-blue-600' : 'bg-gray-50 text-gray-600 border-gray-200'}`}>Agent (B2B)</button>
                </div>
             </div>

             <button disabled={isLoggingIn} className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition flex justify-center">
                {isLoggingIn ? <Loader2 className="animate-spin"/> : 'Register'}
             </button>
          </form>
          <p className="mt-4 text-center text-sm text-gray-500">
             Already have an account? <button onClick={() => setPage('login')} className="text-blue-600 font-bold hover:underline">Log In</button>
          </p>
        </div>
      )}

      {/* Flight Search Results Page */}
      {page === 'flights' && (
         <FlightSearchResults 
            flights={searchedFlights}
            isSearching={isSearchingFlights}
            searchCriteria={{ from: flightFrom, to: flightTo, date: flightDate }}
            onModifySearch={() => setPage('home')}
            onBook={(flight) => {
               alert(`Booking functionality for ${flight.airline} ${flight.flightNumber} coming soon!`);
            }}
         />
      )}

      {/* Other placeholders for pages to make it compilable without errors for now, expanding based on need */}
      {(page === 'hotels' || page === 'packages' || page === 'visa') && (
          <div className="py-20 text-center">
              <h2 className="text-3xl font-bold text-gray-800">{page.charAt(0).toUpperCase() + page.slice(1)}</h2>
              <p className="text-gray-500 mt-2">This section is under development.</p>
              <button onClick={() => setPage('home')} className="mt-6 text-blue-600 hover:underline">Go Back Home</button>
          </div>
      )}

       {/* Profile Page */}
       {page === 'profile' && user && (
        <div className="max-w-2xl mx-auto py-10 px-4">
           <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="bg-slate-900 h-32 relative">
                 <div className="absolute -bottom-10 left-8">
                    <div className="w-24 h-24 bg-white rounded-full p-1 shadow-lg">
                        <div className="w-full h-full bg-blue-500 rounded-full flex items-center justify-center text-3xl font-bold text-white">
                           {user.name.charAt(0)}
                        </div>
                    </div>
                 </div>
              </div>
              <div className="pt-14 px-8 pb-8">
                 <h2 className="text-2xl font-bold text-gray-900">{user.name}</h2>
                 <p className="text-gray-500 flex items-center gap-2"><Mail size={16}/> {user.email}</p>
                 <div className="mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 uppercase tracking-wide">
                    {user.role}
                 </div>
                 
                 <div className="mt-8 border-t border-gray-100 pt-6">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2"><Settings size={18}/> Account Settings</h3>
                    
                    <form onSubmit={handleUpdateProfile} className="space-y-4 mb-8">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Full Name</label>
                            <input type="text" value={profileName} onChange={(e) => setProfileName(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" value={profileEmail} onChange={(e) => setProfileEmail(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
                        </div>
                        <button disabled={isUpdatingProfile} className="bg-blue-600 text-white px-4 py-2 rounded text-sm font-medium hover:bg-blue-700 transition">Update Profile</button>
                    </form>

                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2"><Lock size={18}/> Change Password</h3>
                    <form onSubmit={handleChangePassword} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-gray-700">Current Password</label>
                                <input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">New Password</label>
                                <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"/>
                            </div>
                        </div>
                        <button disabled={isUpdatingProfile} className="bg-slate-800 text-white px-4 py-2 rounded text-sm font-medium hover:bg-slate-900 transition">Change Password</button>
                    </form>
                 </div>
              </div>
           </div>
        </div>
       )}

      {/* Admin/Agent Dashboard Pages */}
      {page === 'dashboard' && (
          <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex justify-between items-start">
                       <div>
                          <p className="text-sm text-gray-500">Total Bookings</p>
                          <h3 className="text-2xl font-bold text-gray-900 mt-1">{allBookings.length}</h3>
                       </div>
                       <div className="bg-blue-100 p-2 rounded-lg text-blue-600"><Briefcase size={20}/></div>
                    </div>
                 </div>
                 {user?.role === UserRole.AGENT && (
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                        <div className="flex justify-between items-start">
                        <div>
                            <p className="text-sm text-gray-500">Wallet Balance</p>
                            <h3 className="text-2xl font-bold text-gray-900 mt-1">৳{user.balance?.toLocaleString() || 0}</h3>
                        </div>
                        <div className="bg-green-100 p-2 rounded-lg text-green-600"><DollarSign size={20}/></div>
                        </div>
                    </div>
                 )}
                 <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                    <div className="flex justify-between items-start">
                       <div>
                          <p className="text-sm text-gray-500">Pending Actions</p>
                          <h3 className="text-2xl font-bold text-gray-900 mt-1">{allBookings.filter(b => b.status === 'PENDING').length}</h3>
                       </div>
                       <div className="bg-orange-100 p-2 rounded-lg text-orange-600"><AlertCircle size={20}/></div>
                    </div>
                 </div>
              </div>

              {/* Recent Bookings Table Preview */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                 <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                    <h3 className="font-bold text-gray-800">Recent Bookings</h3>
                    <button onClick={() => setPage('bookings')} className="text-sm text-blue-600 hover:underline">View All</button>
                 </div>
                 <table className="w-full text-left">
                    <thead className="bg-gray-50">
                       <tr>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">ID</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Service</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Amount</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                       {allBookings.slice(0, 5).map(booking => (
                          <tr key={booking.id}>
                             <td className="px-6 py-4 text-sm font-medium text-gray-900">#{booking.id}</td>
                             <td className="px-6 py-4 text-sm text-gray-500">{booking.details}</td>
                             <td className="px-6 py-4 text-sm text-gray-900">৳{booking.amount.toLocaleString()}</td>
                             <td className="px-6 py-4">
                                <span className={`inline-flex px-2 py-1 text-xs font-bold rounded-full ${booking.status === 'CONFIRMED' ? 'bg-green-100 text-green-800' : booking.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                                   {booking.status}
                                </span>
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
          </div>
      )}

      {page === 'bookings' && (
          <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800">Manage Bookings</h2>
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div className="p-4 border-b border-gray-200 flex flex-col md:flex-row gap-4 items-center justify-between">
                     <div className="flex gap-2">
                         {['ALL', 'CONFIRMED', 'PENDING', 'CANCELLED'].map(s => (
                             <button 
                                key={s} 
                                onClick={() => setBookingStatusFilter(s as any)}
                                className={`px-3 py-1.5 rounded-md text-xs font-bold transition ${bookingStatusFilter === s ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                             >
                                {s}
                             </button>
                         ))}
                     </div>
                </div>
                 <table className="w-full text-left">
                    <thead className="bg-gray-50">
                       <tr>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">ID</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Customer</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Type</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Details</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Amount</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Date</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
                          <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase">Actions</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                       {allBookings.filter(b => bookingStatusFilter === 'ALL' || b.status === bookingStatusFilter).map(booking => (
                          <tr key={booking.id} className="hover:bg-gray-50">
                             <td className="px-6 py-4 text-sm font-medium text-gray-900">#{booking.id}</td>
                             <td className="px-6 py-4 text-sm text-gray-500">{booking.userName}</td>
                             <td className="px-6 py-4 text-sm text-gray-500"><span className="px-2 py-0.5 bg-gray-100 rounded text-xs font-bold">{booking.type}</span></td>
                             <td className="px-6 py-4 text-sm text-gray-500 truncate max-w-[150px]">{booking.details}</td>
                             <td className="px-6 py-4 text-sm text-gray-900">৳{booking.amount.toLocaleString()}</td>
                             <td className="px-6 py-4 text-sm text-gray-500">{booking.date}</td>
                             <td className="px-6 py-4">
                                <span className={`inline-flex px-2 py-1 text-xs font-bold rounded-full ${booking.status === 'CONFIRMED' ? 'bg-green-100 text-green-800' : booking.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                                   {booking.status}
                                </span>
                             </td>
                             <td className="px-6 py-4 text-sm font-medium">
                                <div className="flex items-center gap-2">
                                    <button onClick={() => handleViewDetails(booking)} className="text-gray-400 hover:text-blue-600"><Eye size={18}/></button>
                                    {booking.status === 'PENDING' && (
                                        <>
                                            <button onClick={() => handleConfirmBooking(booking.id)} className="text-green-400 hover:text-green-600"><CheckCircle size={18}/></button>
                                            <button onClick={() => handleCancelBooking(booking.id)} className="text-red-400 hover:text-red-600"><XCircle size={18}/></button>
                                        </>
                                    )}
                                </div>
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
          </div>
      )}

      {page === 'wallet' && user?.role === UserRole.AGENT && (
          <div className="space-y-6">
             <h2 className="text-2xl font-bold text-gray-800">Wallet & Markup</h2>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Balance Card */}
                <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white rounded-xl shadow-lg p-6">
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Available Balance</p>
                            <h3 className="text-4xl font-bold mt-2">৳{user.balance?.toLocaleString() || 0}</h3>
                        </div>
                        <CreditCard className="text-slate-600" size={32}/>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <button onClick={() => setWalletMode('deposit')} className="bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-medium transition text-sm">Deposit Funds</button>
                        <button onClick={() => setWalletMode('withdraw')} className="bg-red-500 hover:bg-red-600 text-white py-2 rounded-lg font-medium transition text-sm">Withdraw</button>
                    </div>
                </div>
                
                {/* Markup Config */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2"><TrendingUp size={20} className="text-blue-600"/> Markup Configuration</h3>
                    <p className="text-sm text-gray-500 mb-6">Set your profit margin. This percentage will be added to the base price of flights and hotels.</p>
                    <div className="flex items-center gap-4">
                         <div className="flex-1 relative">
                            <input 
                                type="number" 
                                value={markup} 
                                onChange={(e) => setMarkup(Number(e.target.value))}
                                className="block w-full border border-gray-300 rounded-lg py-2 pl-3 pr-8 focus:ring-blue-500 focus:border-blue-500"
                            />
                            <span className="absolute right-3 top-2 text-gray-500">%</span>
                         </div>
                         <button onClick={handleMarkupSave} className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition">Save</button>
                    </div>
                </div>
             </div>
             
             {/* Transaction Form (Conditional) */}
             {walletMode !== 'view' && (
                 <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 max-w-md mx-auto animate-in slide-in-from-top-4">
                    <h3 className="font-bold text-gray-900 mb-4">{walletMode === 'deposit' ? 'Deposit Funds' : 'Withdraw Funds'}</h3>
                    <input 
                        type="number" 
                        placeholder="Enter Amount" 
                        className="w-full border border-gray-300 rounded-lg p-3 mb-4 focus:ring-2 focus:ring-blue-500 outline-none"
                        value={transAmount}
                        onChange={(e) => setTransAmount(e.target.value)}
                    />
                    <div className="flex gap-3">
                        <button onClick={() => setWalletMode('view')} className="flex-1 border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50">Cancel</button>
                        <button 
                            onClick={handleTransaction} 
                            disabled={isWalletLoading}
                            className={`flex-1 py-2 rounded-lg text-white font-medium ${walletMode === 'deposit' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                        >
                            {isWalletLoading ? <Loader2 className="animate-spin mx-auto" size={20}/> : 'Confirm'}
                        </button>
                    </div>
                 </div>
             )}
          </div>
      )}

    </Layout>
  );
}