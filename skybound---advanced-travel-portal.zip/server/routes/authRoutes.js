const express = require('express');
const jwt = require('jsonwebtoken');
const { USERS } = require('../db');
const { SECRET_KEY, authenticateToken } = require('../middleware/authMiddleware');

const router = express.Router();

const generateToken = (user) => {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, SECRET_KEY, { expiresIn: '24h' });
};

// Login Endpoint
router.post('/login', (req, res) => {
  const { email, password, role } = req.body;

  const user = USERS.find(u => u.email === email && u.password === password);

  if (!user) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  if (role && user.role !== role) {
     return res.status(403).json({ message: `Access denied. Not a ${role} account.` });
  }

  const token = generateToken(user);
  const { password: _, ...userInfo } = user;
  
  res.json({
    message: 'Login successful',
    token,
    user: userInfo
  });
});

// Register Endpoint
router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;

  if (USERS.find(u => u.email === email)) {
    return res.status(400).json({ message: 'User already exists' });
  }

  const newUser = {
    id: role === 'AGENT' ? `G${USERS.length + 1}` : `C${USERS.length + 1}`,
    name,
    email,
    password, 
    role: role || 'CUSTOMER',
    balance: role === 'AGENT' ? 0 : undefined,
    markup: role === 'AGENT' ? 0 : undefined
  };

  USERS.push(newUser);
  const token = generateToken(newUser);
  const { password: _, ...userInfo } = newUser;

  res.status(201).json({ token, user: userInfo });
});

// Update Profile
router.put('/profile', authenticateToken, (req, res) => {
  const { name, email } = req.body;
  const user = USERS.find(u => u.id === req.user.id);

  if (!user) return res.status(404).json({ message: 'User not found' });

  // Update fields
  if (name) user.name = name;
  if (email) user.email = email; // In a real app, email change might require verification

  const { password: _, ...userInfo } = user;
  res.json({ message: 'Profile updated successfully', user: userInfo });
});

// Change Password
router.post('/change-password', authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = USERS.find(u => u.id === req.user.id);

  if (!user) return res.status(404).json({ message: 'User not found' });

  if (user.password !== currentPassword) {
    return res.status(400).json({ message: 'Incorrect current password' });
  }

  user.password = newPassword;
  res.json({ message: 'Password changed successfully' });
});

module.exports = router;