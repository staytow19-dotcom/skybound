const express = require('express');
const { searchFlights } = require('../services/flightService');

const router = express.Router();

// Search Flights
router.post('/search', async (req, res) => {
  try {
    const { from, to, date, passengers } = req.body;

    if (!from || !to || !date) {
      return res.status(400).json({ message: 'Missing required search fields (from, to, date).' });
    }

    const flights = await searchFlights({ from, to, date, passengers });
    
    res.json({
      success: true,
      count: flights.length,
      data: flights
    });
  } catch (error) {
    console.error('Flight Search Error:', error);
    res.status(500).json({ message: 'Internal server error during flight search.' });
  }
});

module.exports = router;