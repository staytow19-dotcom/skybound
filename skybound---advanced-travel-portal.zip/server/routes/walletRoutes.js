const express = require('express');
const { USERS, TRANSACTIONS } = require('../db');
const { authenticateToken } = require('../middleware/authMiddleware');

const router = express.Router();

// Get Wallet Balance & Config
router.get('/', authenticateToken, (req, res) => {
  const user = USERS.find(u => u.id === req.user.id);
  
  if (user.role !== 'AGENT') {
    return res.status(403).json({ message: 'Only agents have wallets' });
  }

  res.json({ 
    balance: user.balance, 
    markup: user.markup,
    currency: 'BDT' 
  });
});

// Deposit Funds
router.post('/deposit', authenticateToken, (req, res) => {
  const { amount } = req.body;
  const user = USERS.find(u => u.id === req.user.id);

  if (user.role !== 'AGENT') return res.status(403).json({ message: 'Unauthorized' });
  if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });

  user.balance += amount;
  
  TRANSACTIONS.push({
    id: `TXN${Date.now()}`,
    userId: user.id,
    type: 'DEPOSIT',
    amount,
    date: new Date().toISOString()
  });

  res.json({ message: 'Deposit successful', newBalance: user.balance });
});

// Withdraw Funds
router.post('/withdraw', authenticateToken, (req, res) => {
  const { amount } = req.body;
  const user = USERS.find(u => u.id === req.user.id);

  if (user.role !== 'AGENT') return res.status(403).json({ message: 'Unauthorized' });
  if (!amount || amount <= 0) return res.status(400).json({ message: 'Invalid amount' });
  if (user.balance < amount) return res.status(400).json({ message: 'Insufficient funds' });

  user.balance -= amount;

  TRANSACTIONS.push({
    id: `TXN${Date.now()}`,
    userId: user.id,
    type: 'WITHDRAW',
    amount,
    date: new Date().toISOString()
  });

  res.json({ message: 'Withdrawal successful', newBalance: user.balance });
});

// Update Config (Markup)
router.post('/config', authenticateToken, (req, res) => {
  const { markup } = req.body;
  const user = USERS.find(u => u.id === req.user.id);

  if (user.role !== 'AGENT') return res.status(403).json({ message: 'Unauthorized' });
  if (typeof markup !== 'number' || markup < 0 || markup > 100) {
    return res.status(400).json({ message: 'Invalid markup percentage' });
  }

  user.markup = markup;
  res.json({ message: 'Markup updated', markup: user.markup });
});

module.exports = router;