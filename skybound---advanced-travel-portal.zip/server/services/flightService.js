// Mock Flight Provider Service (Simulating FlyHub / Travelport / Sabre)

const AIRLINES = [
  { code: 'BS', name: 'US-Bangla Airlines', logo: 'https://picsum.photos/40/40?random=1' },
  { code: 'BG', name: 'Biman Bangladesh', logo: 'https://picsum.photos/40/40?random=2' },
  { code: 'VQ', name: 'NovoAir', logo: 'https://picsum.photos/40/40?random=3' },
  { code: 'EK', name: 'Emirates', logo: 'https://picsum.photos/40/40?random=10' },
  { code: 'QR', name: 'Qatar Airways', logo: 'https://picsum.photos/40/40?random=11' }
];

const generateRandomFlights = (from, to, date) => {
  const results = [];
  // Generate 3-6 random flights
  const count = Math.floor(Math.random() * 4) + 3;

  for (let i = 0; i < count; i++) {
    const airline = AIRLINES[Math.floor(Math.random() * AIRLINES.length)];
    const priceBase = from === 'DAC' && to === 'CXB' ? 4000 : 15000;
    const price = priceBase + Math.floor(Math.random() * 5000);
    
    // Generate random departure time
    const hour = Math.floor(Math.random() * 24);
    const minute = Math.random() > 0.5 ? '00' : '30';
    const depTime = `${hour.toString().padStart(2, '0')}:${minute}`;
    
    // Calculate arrival (approx 1-4 hours later)
    const duration = Math.floor(Math.random() * 3) + 1;
    const arrHour = (hour + duration) % 24;
    const arrTime = `${arrHour.toString().padStart(2, '0')}:${minute}`;

    results.push({
      id: `FL-${Date.now()}-${i}`,
      airline: airline.name,
      flightNumber: `${airline.code}-${Math.floor(Math.random() * 900) + 100}`,
      from: from.toUpperCase(),
      to: to.toUpperCase(),
      departureTime: depTime,
      arrivalTime: arrTime,
      price: price,
      logo: airline.logo,
      date: date
    });
  }
  return results;
};

const searchFlights = async (criteria) => {
  // Simulate API Network Latency
  await new Promise(resolve => setTimeout(resolve, 800));

  const { from, to, date } = criteria;
  
  // Return generated mock data
  return generateRandomFlights(from, to, date);
};

module.exports = { searchFlights };