// Mock Database Module
const USERS = [
  {
    id: 'A001',
    name: 'Super Admin',
    email: 'admin@skybound.com',
    password: 'password',
    role: 'ADMIN',
    balance: 0,
    markup: 0
  },
  {
    id: 'G001',
    name: 'Travel Link Bd',
    email: 'agent@skybound.com',
    password: 'password',
    role: 'AGENT',
    balance: 50000,
    markup: 5
  },
  {
    id: 'C001',
    name: 'Rahim Ahmed',
    email: 'user@skybound.com',
    password: 'password',
    role: 'CUSTOMER',
    balance: 0,
    markup: 0
  }
];

const TRANSACTIONS = [];

module.exports = { USERS, TRANSACTIONS };