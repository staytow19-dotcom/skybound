import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateTravelItinerary = async (destination: string, days: number, budget: string): Promise<string> => {
  try {
    const prompt = `
      Act as a professional travel agent. 
      Create a detailed ${days}-day travel itinerary for a trip to ${destination}.
      The traveler has a budget of ${budget}.
      Include:
      1. Suggested flight cost estimation.
      2. Recommended hotels or areas to stay.
      3. Day-by-day activity plan.
      4. Estimated daily costs for food and transport.
      
      Format the response with clear headings and bullet points using Markdown.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Sorry, I couldn't generate an itinerary at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "An error occurred while generating the itinerary. Please try again.";
  }
};

export const askTravelAssistant = async (question: string): Promise<string> => {
  try {
     const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: question,
       config: {
         systemInstruction: "You are a helpful customer support agent for 'SkyBound', a travel agency in Bangladesh. You help with flights, visas, and holiday packages."
       }
    });
    return response.text || "I didn't understand that.";
  } catch (e) {
    return "Sorry, I am having trouble connecting right now.";
  }
}